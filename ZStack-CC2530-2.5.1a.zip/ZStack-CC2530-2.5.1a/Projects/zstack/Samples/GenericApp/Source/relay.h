#include <ioCC2530.h>
#include <stdio.h>
#define OPEN_Relay (P1_3=1)
#define CLOSE_Relay (P1_3=0)
void initRelay(void);

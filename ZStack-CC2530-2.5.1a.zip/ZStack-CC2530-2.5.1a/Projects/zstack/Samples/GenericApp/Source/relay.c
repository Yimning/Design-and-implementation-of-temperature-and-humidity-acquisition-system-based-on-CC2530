#include "Relay.h"
void initRelay(void)
{
  P1SEL &=~0x8;
  P1DIR |= 0x8;
  CLOSE_Relay;
}
